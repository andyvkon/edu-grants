# app/main.py
from pathlib import Path
import os
import sqlite3
from typing import List, Optional

from fastapi import FastAPI, Query, Header, HTTPException, APIRouter
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import RedirectResponse
from pydantic import BaseModel

# для админ-ингеста
from .ingest.sources import (
    fetch_ccc_courses,
    fetch_grants_from_csv,
    fetch_nonprofits_demo,
)

# --- Paths & DB ---
BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR.parent / "data" / "data.db"

def q_all(query: str, params: tuple = ()):
    """Безопасный helper: выполняет SELECT и возвращает список dict.
       Если таблицы ещё нет — вернёт [] вместо 500 ошибки.
    """
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    try:
        cur.execute(query, params)
    except sqlite3.OperationalError as e:
        if "no such table" in str(e).lower():
            conn.close()
            return []
        conn.close()
        raise
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return rows

# --- App setup ---
app = FastAPI(title="Edu/Grants API", version="0.2.4")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],   # если фронт всегда на том же хосте — можно сузить
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Раздача статики из /web и домашний редирект на index.html
app.mount("/web", StaticFiles(directory=str(BASE_DIR.parent / "web"), html=True), name="web")

@app.get("/", include_in_schema=False)
def home():
    return RedirectResponse(url="/web/index.html")

# --- Models ---
class Grant(BaseModel):
    id: int
    title: str
    description: Optional[str] = None
    link: Optional[str] = None
    location: Optional[str] = None
    deadline: Optional[str] = None
    tags: Optional[str] = None

class Course(BaseModel):
    id: int
    title: str
    provider: Optional[str] = None
    link: Optional[str] = None
    mode: Optional[str] = None
    location: Optional[str] = None
    category: Optional[str] = None
    tags: Optional[str] = None

class Scholarship(BaseModel):
    id: int
    title: str
    eligibility: Optional[str] = None
    amount: Optional[str] = None
    link: Optional[str] = None
    location: Optional[str] = None
    tags: Optional[str] = None

class Nonprofit(BaseModel):
    id: int
    name: str
    service: Optional[str] = None
    link: Optional[str] = None
    location: Optional[str] = None
    tags: Optional[str] = None

# --- Data endpoints ---
@app.get("/grants", response_model=List[Grant], tags=["data"])
def get_grants(q: Optional[str] = Query(None), location: Optional[str] = None, tags: Optional[str] = None):
    sql = "SELECT * FROM grants"; cond, args = [], []
    if q:        cond += ["(title LIKE ? OR description LIKE ?)"]; args += [f"%{q}%", f"%{q}%"]
    if location: cond += ["location LIKE ?"];                       args += [f"%{location}%"]
    if tags:     cond += ["tags LIKE ?"];                           args += [f"%{tags}%"]
    if cond: sql += " WHERE " + " AND ".join(cond)
    # Важно: deadline хранится как TEXT, лучше ISO YYYY-MM-DD для корректной сортировки
    sql += " ORDER BY deadline IS NULL, deadline ASC"
    return q_all(sql, tuple(args))

@app.get("/courses", response_model=List[Course], tags=["data"])
def get_courses(q: Optional[str] = None, category: Optional[str] = None, provider: Optional[str] = None,
                location: Optional[str] = None, tags: Optional[str] = None):
    sql = "SELECT * FROM courses"; cond, args = [], []
    if q:        cond += ["(title LIKE ? OR provider LIKE ?)"]; args += [f"%{q}%", f"%{q}%"]
    if category: cond += ["category LIKE ?"];                     args += [f"%{category}%"]
    if provider: cond += ["provider LIKE ?"];                     args += [f"%{provider}%"]
    if location: cond += ["location LIKE ?"];                     args += [f"%{location}%"]
    if tags:     cond += ["tags LIKE ?"];                         args += [f"%{tags}%"]
    if cond: sql += " WHERE " + " AND ".join(cond)
    sql += " ORDER BY title ASC"
    return q_all(sql, tuple(args))

@app.get("/scholarships", response_model=List[Scholarship], tags=["data"])
def get_scholarships(q: Optional[str] = None, location: Optional[str] = None, tags: Optional[str] = None):
    sql = "SELECT * FROM scholarships"; cond, args = [], []
    if q:        cond += ["(title LIKE ? OR eligibility LIKE ?)"]; args += [f"%{q}%", f"%{q}%"]
    if location: cond += ["location LIKE ?"];                      args += [f"%{location}%"]
    if tags:     cond += ["tags LIKE ?"];                          args += [f"%{tags}%"]
    if cond: sql += " WHERE " + " AND ".join(cond)
    sql += " ORDER BY title ASC"
    return q_all(sql, tuple(args))

@app.get("/nonprofits", response_model=List[Nonprofit], tags=["data"])
def get_nonprofits(q: Optional[str] = None, location: Optional[str] = None, tags: Optional[str] = None):
    sql = "SELECT * FROM nonprofits"; cond, args = [], []
    if q:        cond += ["(name LIKE ? OR service LIKE ?)"]; args += [f"%{q}%", f"%{q}%"]
    if location: cond += ["location LIKE ?"];                   args += [f"%{location}%"]
    if tags:     cond += ["tags LIKE ?"];                       args += [f"%{tags}%"]
    if cond: sql += " WHERE " + " AND ".join(cond)
    sql += " ORDER BY name ASC"
    return q_all(sql, tuple(args))

# --- /api/* алиасы для фронта (если он ходит на /api/...) ---
api = APIRouter(prefix="/api", tags=["api-alias"])

@api.get("/grants", response_model=List[Grant])
def api_grants(q: Optional[str] = Query(None), location: Optional[str] = None, tags: Optional[str] = None):
    return get_grants(q=q, location=location, tags=tags)

@api.get("/courses", response_model=List[Course])
def api_courses(q: Optional[str] = None, category: Optional[str] = None, provider: Optional[str] = None,
                location: Optional[str] = None, tags: Optional[str] = None):
    return get_courses(q=q, category=category, provider=provider, location=location, tags=tags)

@api.get("/scholarships", response_model=List[Scholarship])
def api_scholarships(q: Optional[str] = None, location: Optional[str] = None, tags: Optional[str] = None):
    return get_scholarships(q=q, location=location, tags=tags)

@api.get("/nonprofits", response_model=List[Nonprofit])
def api_nonprofits(q: Optional[str] = None, location: Optional[str] = None, tags: Optional[str] = None):
    return get_nonprofits(q=q, location=location, tags=tags)

app.include_router(api)

# --- Meta ---
@app.get("/schema", tags=["meta"])
def schema():
    return {"tables": ["grants", "courses", "scholarships", "nonprofits"], "db": str(DB_PATH)}

@app.get("/health", tags=["meta"])
def health():
    return {"ok": True}

# --- Admin ingest endpoints ---
ADMIN_API_KEY = os.getenv("ADMIN_API_KEY", "devkey")

@app.post("/admin/ingest/{source}", tags=["admin"])
def ingest_source(
    source: str,
    csv_url: str | None = None,
    x_api_key: str = Header(None, alias="X-API-Key"),
):
    if x_api_key != ADMIN_API_KEY:
        raise HTTPException(status_code=401, detail="Unauthorized")
    try:
        if source == "ccc_courses":
            return {"ok": True, "source": source, "result": fetch_ccc_courses()}
        elif source == "grants_csv":
            if not csv_url:
                raise HTTPException(status_code=400, detail="csv_url is required")
            return {"ok": True, "source": source, "result": fetch_grants_from_csv(csv_url)}
        elif source == "nonprofits_demo":
            return {"ok": True, "source": source, "result": fetch_nonprofits_demo()}
        else:
            raise HTTPException(status_code=404, detail="unknown source")
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"ingest failed: {type(e).__name__}: {e}")
